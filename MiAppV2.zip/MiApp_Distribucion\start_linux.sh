#!/bin/bash
echo "Iniciando MiApp..."
java -jar MiApp-1.0-SNAPSHOT-jar-with-dependencies.jar

