MiApp - Aplicación Java

Ejecutar en Windows:

SDK 23
---------------------
1. Hacer doble clic en 'start_windows.bat'

Ejecutar en Linux:
------------------
1. Abrir una terminal y navegar a la carpeta de la aplicación
2. Dar permisos de ejecución: chmod +x start_linux.sh
3. Ejecutar: ./start_linux.sh
